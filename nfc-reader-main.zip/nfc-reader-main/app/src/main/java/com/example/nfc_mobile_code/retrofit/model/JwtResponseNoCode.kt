package com.example.nfc_mobile_code.retrofit.model

data class JwtResponseNoCode(val authenticated: Boolean, val token: String)
