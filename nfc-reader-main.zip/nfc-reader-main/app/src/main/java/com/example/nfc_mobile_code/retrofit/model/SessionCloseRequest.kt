package com.example.nfc_mobile_code.retrofit.model

data class SessionCloseRequest(val code: String)
