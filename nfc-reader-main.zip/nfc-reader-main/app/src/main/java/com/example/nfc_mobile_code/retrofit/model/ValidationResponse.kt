package com.example.nfc_mobile_code.retrofit.model

data class ValidationResponse(val valid: Boolean) // Assurez-vous que ce champ correspond à la réponse de l'API
