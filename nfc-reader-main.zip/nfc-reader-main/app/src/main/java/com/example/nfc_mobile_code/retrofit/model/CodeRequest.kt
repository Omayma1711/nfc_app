package com.example.nfc_mobile_code.retrofit.model

data class CodeRequest(val code: String)
