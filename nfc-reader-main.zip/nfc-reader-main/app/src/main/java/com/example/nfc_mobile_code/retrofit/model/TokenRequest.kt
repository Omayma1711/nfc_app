package com.example.nfc_mobile_code.retrofit.model

data class TokenRequest(val code: String, val nfcData: String)
